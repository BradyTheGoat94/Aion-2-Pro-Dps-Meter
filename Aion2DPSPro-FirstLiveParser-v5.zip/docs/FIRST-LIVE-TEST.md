# First live test

This is an EXPERIMENTAL parser build. It passively observes TCP/13328 through Npcap.

1. Install Npcap in WinPcap-compatible mode.
2. Publish x64: `dotnet publish src/Aion2DPSPro.csproj -c Release -r win-x64`.
3. Run the published EXE as Administrator.
4. Enter AION 2, attack a normal mob for 30-60 seconds.
5. Compare visible game damage with the overlay and watch diagnostics.

Good signs: repeated `Parsed damage`, plausible target/actor IDs, and totals that move only when combat damage occurs.
Bad signs: parsed events while idle, enormous implausible values, missing most attacks, or repeated unknown tags.

The parser rejects malformed/implausible packets. The copied opcode profile remains `verified=false` until a real Global capture is compared against in-game observations.

# Live validation gate

Implemented: Npcap/SharpPcap capture, TCP sequence reassembly, varint frame extraction, optional F0-FE marker handling, FF FF LZ4 batch decompression, tag dispatcher, diagnostics, replay recorder.

Validation still required before enabling combat field parsers for a profile: Global-client tags and layouts for Damage, DoT, MobSpawn, UserInfo, Buff, BossHP, Summon and EntityRemoved. This is deliberate: AION 2 has changed opcodes across patches and a plausible parse is worse than an explicit unknown event.

Recommended acceptance test: controlled capture with basic hit, crit, multi-hit, DoT, buff, summon, party damage and boss HP. Replay must reproduce displayed totals with no duplicates/misses before profile Verified=true.

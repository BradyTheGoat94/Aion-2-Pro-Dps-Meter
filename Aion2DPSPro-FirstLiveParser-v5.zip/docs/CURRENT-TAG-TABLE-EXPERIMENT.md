# Current tag-table experiment

Experimental table copied from the current public A2Meter ProtocolOpcodeConfig defaults
observed 2026-10-02.

damage 04 38
dot 05 38
battleStats 2A 38
battleStatsAlt 2B 38
selfInfo 33 36
otherInfo 45 36
mobSpawn 41 36
bossHp 01 8D
guard 03 36
entityRemoved 21 8D
charLookup 4F 36

Reference party bytes: marker 97; list 01; update 02; request 07; accept 0B;
dungeonExit 04; leave 1D; boardRefresh 2A; boardControl 13.

The profile remains verified=false. A tag match validates the discriminator only, not
the entire packet field layout. Decoder diagnostics expose matches and unknown tags.

Source:
https://github.com/a2meter/Aion2Meter/blob/master/src/A2Meter/Dps/Protocol/ProtocolOpcodeConfig.cs

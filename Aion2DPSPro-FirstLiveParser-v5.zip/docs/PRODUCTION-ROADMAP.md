# Remaining work before claiming live accuracy

The application shell is production-oriented, but the exact AION 2 decoder is intentionally
not fabricated.

Required final step:

- Add a validated `IAion2Decoder` implementation for the exact current client.
- Add TCP stream reassembly if payload boundaries are not packet-aligned.
- Add connection/port auto-detection.
- Add packet-recording replay tests.
- Validate actor/name mapping.
- Validate summon-owner mapping.
- Validate target HP.
- Validate all damage flags.
- Validate fight boundaries.
- Validate against known combat-log samples.

Once those tests pass, the same decoder feeds the already-built analytics and overlay layers.

# Decoder research status — 2026-10-02

Public implementations independently support this pipeline:

Npcap -> TCP reassembly -> stream framing -> optional LZ4 -> packet dispatch -> combat events.

Design decisions applied here:
- Reassemble TCP before decoding; never assume one TCP segment == one game message.
- Keep damage and HP as signed 64-bit values end-to-end.
- Keep opcodes/layouts in a versioned ProtocolProfile because AION 2 updates have shifted opcodes.
- Record raw reassembled stream data + metadata for deterministic replay.
- Unknown/unverified packets produce diagnostics, never guessed damage events.
- Summon attribution, DoT attribution, front/back/perfect/crit flags, deaths, buffs, party identity and boss HP are validation targets.

References used for architecture:
- https://github.com/a2meter/Aion2Meter
- https://github.com/Kuroukihime/AIon2-Dps-Meter
- https://github.com/taengu/A2Tools-DPS-Meter

Important: upstream repositories use GPL licenses in several cases. This project should not copy GPL implementation code into a differently licensed distribution without complying with the applicable license. The current additions are independently written architectural scaffolding based on publicly documented behavior.

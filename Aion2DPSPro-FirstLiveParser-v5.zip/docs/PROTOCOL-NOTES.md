# Protocol notes

As of the current public projects reviewed for this build:

- A2Tools captures AION 2 network packets and requires Npcap/WinPcap-compatible mode.
- A2Tools release notes document client updates that changed packet opcodes and required
  parser fixes.
- A2Tools release notes also document live boss HP parsing, DoT tracking, summon-owner
  attribution, damage-type flags, and port auto-detection.
- Aion2Flow documents a WinDivert-based Windows capture path and does not read game
  memory or inject into the game.
- Multiple projects note that names may arrive in separate events, so a combat event
  can initially have an actor ID rather than a nickname.

For this project, the decoder must be validated against the exact client/region build.
Do not copy guessed offsets from another release.

Recommended validation procedure:

1. Capture traffic from character select -> game world -> training dummy.
2. Capture a known single-hit skill.
3. Capture a known multi-hit skill.
4. Capture a critical hit, back/frontal hit, DoT tick, parry/block, and perfect hit.
5. Capture a boss HP update and boss phase heal/reset.
6. Capture buff apply/remove and stack changes.
7. Compare every normalized event with the in-game combat result.
8. Freeze the decoder profile with a client build identifier.

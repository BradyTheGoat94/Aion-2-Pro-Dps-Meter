using SharpPcap;
using PacketDotNet;
using Aion2DPSPro.Protocol;

namespace Aion2DPSPro.Capture;

public sealed class LiveCaptureAdapter : IDisposable
{
    private readonly IAion2Decoder decoder;
    private readonly List<ICaptureDevice> devices = new();
    private readonly TcpStreamReassembler reassembler = new();

    public event Action<CombatEvent>? EventReceived;
    public event Action<string>? StatusChanged;

    public LiveCaptureAdapter(IAion2Decoder decoder) => this.decoder = decoder;

    public void Start()
    {
        var available = CaptureDeviceList.Instance;
        if (available.Count == 0) { StatusChanged?.Invoke("No packet capture adapter found. Install Npcap."); return; }
        foreach (var d in available)
        {
            try
            {
                d.OnPacketArrival += OnPacket;
                d.Open(DeviceModes.Promiscuous, 1000);
                d.Filter = "tcp port 13328";
                d.StartCapture();
                devices.Add(d);
            }
            catch { try { d.Close(); } catch { } }
        }
        StatusChanged?.Invoke($"Listening for AION 2 traffic on {devices.Count} adapter(s), TCP/13328.");
    }

    private void OnPacket(object sender, PacketCapture capture)
    {
        var raw = capture.GetPacket();
        var packet = Packet.ParsePacket(raw.LinkLayerType, raw.Data);
        var tcp = packet.Extract<TcpPacket>();
        if (tcp?.PayloadData is not { Length: > 0 }) return;

        var ip = packet.Extract<IPPacket>();
        if (ip == null) return;
        var flow = $"{ip.SourceAddress}:{tcp.SourcePort}>{ip.DestinationAddress}:{tcp.DestinationPort}";
        foreach (var chunk in reassembler.Push(flow, tcp.SequenceNumber, tcp.PayloadData))
        foreach (var d in decoder.Decode(chunk, DateTime.UtcNow))
            EventReceived?.Invoke(new CombatEvent(DateTime.UtcNow, d.Kind, d.SourceId, d.Source,
                d.TargetId, d.Target, d.Skill, d.Amount, d.DamageType,
                d.CurrentHp, d.MaxHp, d.Effect, d.Stacks));
    }

    public void Dispose()
    {
        foreach (var d in devices) { try { d.StopCapture(); } catch { } try { d.Close(); } catch { } }
        devices.Clear();
    }
}

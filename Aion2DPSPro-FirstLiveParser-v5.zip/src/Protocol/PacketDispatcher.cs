namespace Aion2DPSPro.Protocol;

/// Experimental parser adapted from the public A2Meter event layout. Every read is bounds-checked;
/// implausible packets are rejected and logged rather than emitted as combat data.
public sealed class PacketDispatcher
{
    private readonly ProtocolProfile profile;
    public event Action<DecoderDiagnostic>? Diagnostic;
    public PacketDispatcher(ProtocolProfile profile) => this.profile = profile;

    public IEnumerable<Aion2Decoded> Dispatch(ReadOnlySpan<byte> frame, DateTime utc)
    {
        int p=0;
        if (!ProtocolUtils.TryReadVarUInt(frame, ref p, out _, out _)) yield break;
        if (p+1>=frame.Length) yield break;
        byte a=frame[p], b=frame[p+1];
        var kind = profile.Tags.FirstOrDefault(kv => kv.Value.A==a && kv.Value.B==b).Key;
        if (kind is null) { Diagnostic?.Invoke(new(utc,"dispatch",$"Unknown tag 0x{a:X2}{b:X2}",frame.Length)); yield break; }

        Aion2Decoded? evt = kind switch {
            "damage" => TryDamage(frame, p+2, utc),
            "dot" => TryDot(frame, p+2, utc),
            "bossHp" => TryBossHp(frame, p+2, utc),
            _ => null
        };
        if (evt is not null) { Diagnostic?.Invoke(new(utc,"parse",$"Parsed {kind}",frame.Length)); yield return evt; }
        else Diagnostic?.Invoke(new(utc,"dispatch",$"Matched {kind}; no validated event emitted",frame.Length));
    }

    private Aion2Decoded? TryDamage(ReadOnlySpan<byte> d, int p, DateTime utc)
    {
        if (!ReadV(d, ref p, out var target)) return null;
        if (!ReadV(d, ref p, out var flags1)) return null;
        var category=(int)(flags1 & 0xF); if (category<4 || category>7) return null;
        if (!ReadV(d, ref p, out _)) return null;
        if (!ReadV(d, ref p, out var actor) || actor==target || actor==0 || target==0) return null;

        // Public reference resolves skill IDs from packet bytes using a skill database. Until that
        // catalog is embedded, accept a bounded varint candidate and retain its numeric identity.
        if (!ReadV(d, ref p, out var skill) || skill==0 || skill>200_000_000) return null;
        if (!ReadV(d, ref p, out var damageType)) return null;

        int[] trailing={0,0,0,0,8,12,10,14};
        byte flagByte=0; int adjust=0;
        if (p+1<d.Length && (p+2>=d.Length || d[p+1]==0)) { flagByte=d[p]; p+=2; adjust=1; }
        int trailer=trailing[category]-adjust*2; if (trailer<0 || p+trailer>d.Length) return null; p+=trailer;
        if (!ReadV(d, ref p, out _)) return null;
        if (!ReadV(d, ref p, out var damage) || damage==0 || damage>9_000_000_000UL) return null;

        var dtype = DecodeType((byte)damageType, flagByte);
        return new(CombatKind.Damage, actor, $"Actor {actor}", target, $"Target {target}",
            $"Skill {skill}", (long)damage, dtype, 0,0,"",0);
    }

    private Aion2Decoded? TryDot(ReadOnlySpan<byte> d, int p, DateTime utc)
    {
        if (!ReadV(d, ref p, out var target) || p>=d.Length) return null;
        bool hasExtra=(d[p++] & 2)!=0;
        if (!ReadV(d, ref p, out var actor) || actor==target || actor==0) return null;
        if (!ReadV(d, ref p, out var heal)) return null;
        if (p+4>d.Length) return null;
        uint raw=(uint)(d[p] | d[p+1]<<8 | d[p+2]<<16 | d[p+3]<<24); p+=4;
        long damage=0; if (hasExtra && ReadV(d,ref p,out var x)) damage=(long)x;
        uint skill=raw/100; if (skill==0) return null;
        if (damage<=0 && heal<=0) return null;
        return new(damage>0?CombatKind.Damage:CombatKind.Heal, actor,$"Actor {actor}",target,$"Target {target}",
            $"Skill {skill}", damage>0?damage:(long)heal, DamageType.Dot,0,0,"",0);
    }

    private Aion2Decoded? TryBossHp(ReadOnlySpan<byte> d, int p, DateTime utc)
    {
        if (!ReadV(d,ref p,out var entity) || entity==0) return null;
        // Layout varies; conservatively scan the remaining payload for two plausible adjacent varints.
        for(int i=p;i<d.Length;i++) { int q=i; if(!ReadV(d,ref q,out var cur)) continue; if(!ReadV(d,ref q,out var max)) continue;
            if(max>0 && cur<=max && max>=1000 && max<=long.MaxValue)
                return new(CombatKind.TargetHp,0,"",entity,$"Target {entity}","",0,DamageType.Unknown,(long)cur,(long)max,"",0);
        }
        return null;
    }

    private static bool ReadV(ReadOnlySpan<byte> d, ref int p, out ulong value) {
        value=0; int shift=0; for(int n=0;n<10 && p<d.Length;n++) { byte b=d[p++]; value|=(ulong)(b&0x7F)<<shift; if((b&0x80)==0)return true; shift+=7; } value=0; return false;
    }
    private static DamageType DecodeType(byte t, byte flags) {
        if ((flags & 0x02)!=0) return DamageType.Back;
        if ((flags & 0x01)!=0) return DamageType.Frontal;
        if ((t & 0x02)!=0) return DamageType.Crit;
        return DamageType.Direct;
    }
}

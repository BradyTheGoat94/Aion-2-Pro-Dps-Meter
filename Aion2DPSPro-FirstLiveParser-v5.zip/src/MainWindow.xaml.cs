using System.Windows;
using System.Windows.Threading;
using Aion2DPSPro.Capture;
using Aion2DPSPro.Overlay;
using Aion2DPSPro.Protocol;

namespace Aion2DPSPro;

public partial class MainWindow : Window
{
    readonly CombatEngine engine = new();
    readonly DispatcherTimer timer = new() { Interval = TimeSpan.FromMilliseconds(250) };
    readonly OverlayWindow overlay = new();
    readonly LiveCaptureAdapter capture;
    readonly List<OverlayWindow> extraOverlays = new();
    readonly PreviewCombatAdapter preview = new();
    readonly DispatcherTimer previewTimer = new() { Interval = TimeSpan.FromSeconds(1) };

    public MainWindow()
    {
        InitializeComponent();
        var profilePath = System.IO.Path.Combine(AppContext.BaseDirectory, "Protocol", "Profiles", "global-current.json");
        ProtocolProfile profile;
        try { profile = ProtocolProfile.Load(profilePath); }
        catch { profile = ProtocolProfile.SafeGlobalScaffold(); }
        var decoder = new CurrentClientDecoder(profile);
        decoder.Diagnostic += d => Dispatcher.Invoke(() =>
            Status.Text = $"[{d.Stage}] {d.Message} ({d.Bytes} bytes) — profile: {decoder.ProfileId}");
        capture = new LiveCaptureAdapter(decoder);
        capture.EventReceived += e => Dispatcher.Invoke(() => engine.Apply(e));
        capture.StatusChanged += s => Dispatcher.Invoke(() => Status.Text = s);
        timer.Tick += (_, _) => Render();
        engine.PreviewMode = true;
        previewTimer.Tick += (_, _) => { foreach (var ev in preview.Tick()) engine.Apply(ev); };
        previewTimer.Start();
        timer.Start();
        capture.Start();
    }

    void OpenOverlay(object sender, RoutedEventArgs e)
    {
        if (!overlay.IsVisible) overlay.Show();
        overlay.Activate();
    }

    void Reset(object sender, RoutedEventArgs e) => engine.ResetFight();

    void Render()
    {
        var s = engine.Snapshot();
        Dps.Text = $"{s.FightDps:0} DPS";
        Damage.Text = $"{s.FightDamage:N0} damage";
        Target.Text = s.Target is null ? "No target" :
            $"{s.Target.Name}  {s.Target.Percent:0.0}%  {s.Target.CurrentHp:N0}/{s.Target.MaxHp:N0}";
        Grid.ItemsSource = s.Players.Select((p,i) => new {
            Rank=i+1, p.Name, Dps=p.Dps.ToString("N0"), Damage=p.Damage.ToString("N0"), Share=$"{p.Share:0.0}%"
        }).ToList();
        overlay.Render(s);
    }

    protected override void OnClosed(EventArgs e)
    {
        timer.Stop();
        previewTimer.Stop();
        capture.Dispose();
        overlay.Close();
        foreach (var w in extraOverlays) w.Close();
        base.OnClosed(e);
    }
}

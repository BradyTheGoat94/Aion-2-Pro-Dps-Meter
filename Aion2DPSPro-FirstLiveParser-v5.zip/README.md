# Aion2DPSPro Production

Production-oriented Windows x64 architecture for an AION 2 passive network DPS meter.

## What is implemented

- Multi-window transparent always-on-top overlay architecture
- Drag/move and click-through modes
- Current-fight DPS + total damage
- Overall/session DPS + total damage
- Party ranking and contribution
- Skill/category aggregation
- Boss/target model with live HP fields
- Buff/debuff state model and uptime calculation
- Fight state machine and idle finalization
- Detailed combat-event history model
- JSONL local persistence for completed fights
- 250 ms UI snapshot cadence
- Protocol-version boundary
- Raw packet capture boundary
- Packet recording for decoder validation
- No game memory reads, injection, packet modification, or automation

## The exact live decoder

The current AION 2 protocol is version-sensitive. Public current meters document
that client patches have changed packet opcodes and damage fields, and current
projects update their parsers accordingly. This repository therefore deliberately
does NOT contain fabricated opcode/offset values.

To make this build truly live and accurate, implement the current `IAion2Decoder`
for the exact region/client you use, or supply a packet capture from that client.
The capture layer already accepts TCP payloads and the decoder interface is isolated
from the UI/analytics layers.

This is intentional: a meter that guesses packet fields is worse than one that
reports "decoder unavailable."

## Current public evidence

A2Tools documents real-time packet capture, boss HP, DoT, summon attribution,
history, and transparent overlays. Aion2Flow documents a Windows WinDivert capture
path and current overlay/history features. See docs/PROTOCOL-NOTES.md.

## Build

Requires Windows 10/11 x64 and .NET 8 SDK.

```
dotnet build
dotnet run --project src/Aion2DPSPro.csproj
```

The project includes a safe `RecordedCaptureAdapter` for testing the analytics
engine with normalized events. Replace it with `LiveCaptureAdapter` plus the
versioned decoder once the current protocol profile is available.

## Production checklist

1. Install the passive capture driver approved for your environment.
2. Run the app elevated if the capture driver requires it.
3. Select the exact AION 2 region/client profile.
4. Validate decoder against recorded packets.
5. Compare every decoded damage event against the in-game combat log.
6. Enable live overlay.
7. Enable fight-history persistence.


## Overlay theme

The production overlay is styled in a dark blue/red Details-inspired theme:
- Dark navy transparent panels
- Blue headers and secondary information
- Red damage/boss-health accents
- High-contrast white text
- Blue/red visual hierarchy for readable combat data

## Details-style blue/red overlay build
This revision implements the generated mockup direction as a real WPF overlay: blue/red chrome, current-fight selector, damage tabs, class-colored player rows and bars, boss HP, group DPS, player detail panel, skill list, resizing, dragging, and Windows click-through support.

### Class palette
The default global-facing class set is Gladiator, Templar, Assassin, Ranger, Sorcerer, Spiritmaster, Cleric, and Chanter. Brawler has a reserved color for regional/version compatibility but is not shown in the generated global preview party.

### Accuracy guardrail
The included preview adapter generates deterministic synthetic combat events and the overlay visibly says **SIMULATED PREVIEW**. It is intended for UI testing only. `CurrentClientDecoder` remains the live protocol boundary and does not invent packet layouts. Do not interpret preview DPS, skills, HP, or names as game-derived values.

## Protocol hardening added

The live path now includes TCP sequence reassembly scaffolding and versioned protocol-profile/replay components. This follows behavior independently documented by current public AION 2 meters. Exact packet framing/opcodes remain intentionally disabled until matched to a current Global build; unknown traffic is never converted into guessed damage.

## Decoder implementation update
The live pipeline now contains TCP reassembly, current AION varint stream framing, optional type-marker handling, LZ4 batch decompression, profile-driven tag dispatch, unknown-packet diagnostics, and multi-adapter TCP/13328 capture. Packet field layouts/tags remain externally versioned and intentionally unverified until checked against a Global-client capture; the application will not turn unknown bytes into fake DPS.

## v4 experimental current tag table

The current public A2Meter default tag table is enabled as an experimental profile.
The main status line shows matched/unknown decoder tags. Field-level DPS parsing remains
validation-gated, preventing a matching tag from silently producing fabricated totals.
See `docs/CURRENT-TAG-TABLE-EXPERIMENT.md`.

## v5 first-test parser

Experimental field parsing is now enabled for Damage (04 38), DoT (05 38), and conservative BossHP detection. All reads are bounds-checked and implausible values are rejected. Actor/target names and exact skill names remain numeric until entity/skill databases are integrated. The project is configured for a self-contained win-x64 single-file publish. See `docs/FIRST-LIVE-TEST.md`.
